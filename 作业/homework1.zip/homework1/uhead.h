#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define UNUMBER 100

int usum(int* , int);
void urand(int* , int);
void show(int* , int);



